print('Satellite SSC module')
