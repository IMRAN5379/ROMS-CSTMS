import numpy as np

def rating_func(Q,a,b): return a*(Q**b)
