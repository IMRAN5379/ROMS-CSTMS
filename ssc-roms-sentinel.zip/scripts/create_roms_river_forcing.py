print('ROMS forcing generator')
