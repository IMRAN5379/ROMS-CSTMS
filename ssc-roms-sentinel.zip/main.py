print('Run full pipeline here')
